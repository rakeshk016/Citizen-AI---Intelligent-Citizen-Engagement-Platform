citizen_ai_app/
│
├── app.py
├── templates/
│   ├── index.html
│   ├── chat.html
│   ├── sentiment.html
│   └── dashboard.html
├── static/
│   └── styles.css
└── requirements.txt
