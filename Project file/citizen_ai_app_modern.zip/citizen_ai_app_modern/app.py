
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'supersecretkey'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat')
def chat():
    session.setdefault('history', [])
    return render_template('chat.html', history=session['history'])

@app.route('/sentiment')
def sentiment():
    return render_template('sentiment.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/chat', methods=['POST'])
def api_chat():
    user_input = request.json['message']
    response = f"Simulated response for: {user_input}"
    session['history'].append({'user': user_input, 'bot': response})
    return jsonify({'response': response})

@app.route('/api/sentiment', methods=['POST'])
def api_sentiment():
    feedback = request.form['feedback']
    if not feedback.strip():
        flash('Please enter feedback first!', 'danger')
        return redirect(url_for('sentiment'))
    sentiment = "Positive" if "good" in feedback.lower() else "Neutral"
    flash(f"Sentiment detected: {sentiment}", 'success')
    return redirect(url_for('sentiment'))

if __name__ == '__main__':
    app.run(debug=True)
